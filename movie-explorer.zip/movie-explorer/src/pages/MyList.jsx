import { useMyList } from '../context/MyListContext';
import MovieCard from '../components/MovieCard';

function MyList() {
  const { myList } = useMyList();

  return (
    <div>
      <h2>My List</h2>
      {myList.length === 0 ? (
        <p>No movies in your list.</p>
      ) : (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
          {myList.map(movie => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
      )}
    </div>
  );
}

export default MyList;
