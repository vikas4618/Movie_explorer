import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { fetchMovieDetails } from '../api/tmdb';
import MovieCard from '../components/MovieCard';
import { useMyList } from '../context/MyListContext';

function MovieDetails() {
  const { id } = useParams();
  const [movie, setMovie] = useState(null);

  const { addToList, removeFromList, isInList } = useMyList();
  const inList = isInList(id);

  useEffect(() => {
    fetchMovieDetails(id).then((data) => {
      if (data) setMovie(data);
      else setMovie({ error: true });
    });
  }, [id]);

  if (!movie) return <p>Loading...</p>;
  if (movie.error) return <p>Error loading movie. Please try again.</p>;

  const { title, overview, poster_path, vote_average, cast, director, similar } = movie;

  return (
    <div style={{ padding: '20px' }}>
      <div style={{ display: 'flex', gap: '20px', marginBottom: '20px' }}>
        <img
          src={`https://image.tmdb.org/t/p/w300${poster_path}`}
          alt={title}
          style={{ borderRadius: '8px', maxHeight: '450px' }}
        />

        <div style={{ flex: 1 }}>
          <h2>{title}</h2>
          <p><strong>Rating:</strong> {vote_average}/10</p>

          <button
            onClick={() => inList ? removeFromList(movie.id) : addToList(movie)}
            style={{
              padding: '10px 20px',
              margin: '10px 0',
              backgroundColor: inList ? 'red' : 'green',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontWeight: 'bold'
            }}
          >
            {inList ? 'Remove from My List' : 'Add to My List'}
          </button>

          <p><strong>Overview:</strong> {overview}</p>
          <p><strong>Director:</strong> {director}</p>
        </div>
      </div>

      <div>
        <h3>Cast</h3>
        <ul>
          {cast.slice(0, 5).map((member) => (
            <li key={member.id}>
              {member.name} as {member.character}
            </li>
          ))}
        </ul>
      </div>

      <div>
        <h3>Similar Movies</h3>
        <div style={{ display: 'flex', overflowX: 'auto', gap: '10px' }}>
          {similar.map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default MovieDetails;
