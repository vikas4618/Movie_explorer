import MovieSection from '../components/MovieSection';

function Home() {
  return (
    <div>
      <MovieSection type="now_playing" title="Now Playing" />
      <MovieSection type="popular" title="Popular" />
      <MovieSection type="top_rated" title="Top Rated" />
      <MovieSection type="upcoming" title="Upcoming" />
    </div>
  );
}

export default Home;
