import { createContext, useContext, useEffect, useState } from 'react';

const MyListContext = createContext();

export const useMyList = () => useContext(MyListContext);

export const MyListProvider = ({ children }) => {
  const [myList, setMyList] = useState(() => {
    const stored = localStorage.getItem('myList');
    return stored ? JSON.parse(stored) : [];
  });

  useEffect(() => {
    localStorage.setItem('myList', JSON.stringify(myList));
  }, [myList]);

  const addToList = (movie) => {
    if (!myList.some(m => m.id === movie.id)) {
      setMyList([...myList, movie]);
    }
  };

  const removeFromList = (id) => {
    setMyList(myList.filter(m => m.id !== id));
  };

  const isInList = (id) => myList.some(m => m.id === id);

  return (
    <MyListContext.Provider value={{ myList, addToList, removeFromList, isInList }}>
      {children}
    </MyListContext.Provider>
  );
};
