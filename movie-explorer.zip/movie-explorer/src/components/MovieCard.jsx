import { Link } from 'react-router-dom';

function MovieCard({ movie }) {
  const img = movie.poster_path
    ? `https://image.tmdb.org/t/p/w200${movie.poster_path}`
    : 'https://via.placeholder.com/120x180?text=No+Image';

  return (
    <Link to={`/movie/${movie.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
      <div style={{ marginRight: 10, textAlign: 'center' }}>
        <img src={img} alt={movie.title} width="120" />
        <p style={{ width: 120, fontSize: 12 }}>{movie.title}</p>
      </div>
    </Link>
  );
}

export default MovieCard;
