import { useEffect, useState } from 'react';
import { fetchMovies } from '../api/tmdb';
import MovieCard from './MovieCard';

function MovieSection({ type, title }) {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    fetchMovies(type).then(setMovies);
  }, [type]);

  return (
    <div style={{ marginBottom: 30 }}>
      <h2>{title}</h2>
      <div style={{ display: 'flex', overflowX: 'auto' }}>
        {movies.map((movie) => (
          <MovieCard key={movie.id} movie={movie} />
        ))}
      </div>
    </div>
  );
}

export default MovieSection;
