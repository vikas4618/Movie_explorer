import MovieDetails from './pages/MovieDetails';
import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import MyList from './pages/MyList';
import Sidebar from './components/Sidebar';

function App() {
  return (
    <div style={{ display: 'flex' }}>
      <Sidebar />
      <div style={{
        marginLeft: 240, // same width as MUI Drawer
        padding: '20px',
        width: '100%',
        boxSizing: 'border-box',
        minHeight: '100vh',
        backgroundColor: '#f5f5f5'
      }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/my-list" element={<MyList />} />
          <Route path="/movie/:id" element={<MovieDetails />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
