const API_KEY = import.meta.env.VITE_TMDB_API_KEY;
const BASE_URL = 'https://api.themoviedb.org/3';

export const fetchMovies = async (type) => {
  try {
    const res = await fetch(`${BASE_URL}/movie/${type}?api_key=${API_KEY}`);
    const data = await res.json();
    return data.results;
  } catch (error) {
    console.error("TMDB Fetch Error:", error);
    return [];
  }
};

export const fetchMovieDetails = async (id) => {
  const API_KEY = import.meta.env.VITE_TMDB_API_KEY;
  const BASE_URL = 'https://api.themoviedb.org/3';

  try {
    const [detailsRes, creditsRes, similarRes] = await Promise.all([
      fetch(`${BASE_URL}/movie/${id}?api_key=${API_KEY}`),
      fetch(`${BASE_URL}/movie/${id}/credits?api_key=${API_KEY}`),
      fetch(`${BASE_URL}/movie/${id}/similar?api_key=${API_KEY}`)
    ]);

    const details = await detailsRes.json();
    const credits = await creditsRes.json();
    const similar = await similarRes.json();

    const director = credits.crew.find(person => person.job === 'Director')?.name || 'Unknown';

    return {
      ...details,
      cast: credits.cast,
      director,
      similar: similar.results || []
    };
  } catch (error) {
    console.error("Error fetching movie details:", error);
    return null;
  }
};
